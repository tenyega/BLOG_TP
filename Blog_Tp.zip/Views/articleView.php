<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Article Details </title>
    <link rel="stylesheet" href="Assets/style.css">
</head>

<body>


    <h1 class="title"> Detail of the selected article</h1>
    <?php if (!empty($articleInfos)): ?>
        <div class="article-grid-detail">
            <?php foreach ($articleInfos as $articleInfo) : ?>

                <div class="article-card">
                    <h2 class="article-title"><?= $articleInfo['title']; ?></h2>
                    <p class="article-meta">
                        <span class="article-author">By <?= $articleInfo['author']; ?></span> |
                        <span class="article-date">Published on <?= $articleInfo['date_pub']; ?></span>
                    </p>
                    <p class="article-content"><?= $articleInfo['content']; ?></p>
                    <p class="article-category">Category: <?= $articleInfo['category']; ?></p>

                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <h1 class="title"> No Records Found</h1>
        <?php endif ?>

</body>

</html>