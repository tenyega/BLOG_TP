<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Article Details </title>
    <link rel="stylesheet" href="Assets/style.css">
</head>

<body>


    <h1 class="title"> Detail of the Author</h1>
    <?php if (!empty($authorDetails)): ?>

        <div class="article-grid-detail">
            <?php foreach ($authorDetails as $authorDetail) : ?>

                <div class="article-card">
                    <h2 class="article-title"><?= strtoupper($authorDetail['author']); ?></h2>
                    <p class="article-meta">
                        <span class="article-date">Born on <?= $authorDetail['dob']; ?></span>
                    </p>
                    <p class="article-content">Phone no <?= $authorDetail['phone']; ?></p>
                    <p class="article-content">Address : <?= $authorDetail['address']; ?></p>
                    <p class="article-category">Books written : <?= $authorDetail['title']; ?></p>

                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <h1 class="title"> No Records Found</h1>
        <?php endif ?>


</body>

</html>