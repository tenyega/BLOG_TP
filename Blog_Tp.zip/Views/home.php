<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to My Blog</title>
    <link rel="stylesheet" href="Assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

</head>

<body>
    <h1 class='title'>Welcome to My Blog</h1>

    <div class="navbar">

        <form action="">
            <label>
                Search a Title
                <input type="text" name="title" value="<?= $_GET['title'] ?? '' ?>">
            </label>
            <button type="submit"><i class="fas fa-search"></i> Search</button>
        </form>
        <form action="">
            <label>
                Search Content
                <input type="text" name="content" value="<?= $_GET['content'] ?? '' ?>">
            </label>
            <button type="submit"><i class="fas fa-search"></i> Search</button>
        </form>
        <form action="">
            <label>
                Search By Category
                <select name="category_id">
                    <?php foreach ($categories as $category) : ?>
                        <option value="<?= $category['id'] ?>" <?= !empty($_GET['category_id']) && $_GET['category_id'] == $category['id'] ? 'selected' : '' ?>><?= $category['name'] ?></option>
                    <?php endforeach ?>
                </select>
            </label>
            <button type="submit"><i class="fas fa-search"></i> Search</button>
        </form>

        <form action="">
            <label>
                Search By Author
                <input type="text" name="author" value="<?= $_GET['author'] ?? '' ?>">
            </label>
            <button type="submit"><i class="fas fa-search"></i> Search</button>
        </form>
        <form action="">
            <label for="date_pub">
                Search using Publication Date
                <input type="date" name="date_pub" value="<?= $_GET['date_pub'] ?? '' ?>">
            </label>
            <button type="submit"><i class="fas fa-search"></i> Search</button>
        </form>
    </div>



    <?php if (!empty($articles)): ?>

        <div class="article-grid">
            <?php foreach ($articles as $article) : ?>
                <a href="article.php?id=<?= $article['id'] ?>" class="article-link">
                    <div class="article-card">
                        <h3 class="article-title"><?= $article['title'] ?></h3>
                        <h3 class="article-author">Author :- <?= $article['author'] ?></h3><br>
                        <p class="article-date">Published On :- <?= $article['date_pub'] ?></p><br>
                        <p class="article-date">Category :- <?= $article['category'] ?></p>
                    </div>
                </a>

            <?php endforeach ?>
        <?php else : ?>
            <h1 class="title"> No Records Found</h1>
        <?php endif ?>
        </div>
</body>

</html>